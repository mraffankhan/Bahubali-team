CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    profile_photo VARCHAR(255) DEFAULT NULL
);

CREATE TABLE groups (
    id INT AUTO_INCREMENT PRIMARY KEY,       -- Unique ID for each group
    name VARCHAR(100) NOT NULL,               -- Name of the group
    description TEXT,                         -- Description of the group (optional)
    created_by INT NOT NULL,                  -- ID of the user who created the group
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- Timestamp when the group was created (auto-generated)
);


CREATE TABLE calls (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caller_id INT NOT NULL,
    callee_id INT NOT NULL,
    call_type VARCHAR(50) NOT NULL,  -- Call type (e.g., 'voice', 'video')
    call_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    call_end TIMESTAMP,
    call_status VARCHAR(20) NOT NULL  -- Call status (e.g., 'completed', 'missed', 'ongoing')
);

CREATE TABLE group_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    user_id INT NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,  -- 1 for admin, 0 for non-admin
    added_by INT NOT NULL,  -- The ID of the user who added this member to the group
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    status VARCHAR(20) NOT NULL,  -- Message status (e.g., 'sent', 'delivered', 'read')
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE channels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    server_id INT NOT NULL,  -- The ID of the server to which this channel belongs
    name VARCHAR(255) NOT NULL -- The name of the channel
);

CREATE TABLE group_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique ID for each message
    group_id INT NOT NULL,                    -- ID of the group where the message was sent
    sender_id INT NOT NULL,                   -- ID of the user who sent the message
    message TEXT NOT NULL,                    -- The message content
    created_at DATETIME NOT NULL,             -- Timestamp when the message was created
    deleted_by TEXT NULL                      -- Users who deleted the message (if any)
);

CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique ID for each message
    sender_id INT NOT NULL,                   -- ID of the user who sent the message
    receiver_id INT NOT NULL,                 -- ID of the user receiving the message
    message TEXT NOT NULL,                    -- The message content
    created_at DATETIME NOT NULL,             -- Timestamp when the message was sent
    deleted_by_sender BOOLEAN DEFAULT 0,      -- Whether the message was deleted by the sender (0 = no, 1 = yes)
    deleted_by_receiver BOOLEAN DEFAULT 0,    -- Whether the message was deleted by the receiver (0 = no, 1 = yes)
    channel_id INT DEFAULT 0,                 -- ID of the channel (0 if not in a channel)
    user_id INT DEFAULT 0                     -- ID of the user (relevant for users in the system)
);

CREATE TABLE servers (
    id INT AUTO_INCREMENT PRIMARY KEY,        -- Unique ID for each server
    name VARCHAR(255) NOT NULL,                -- Name of the server
    owner_id INT NOT NULL                      -- ID of the user who owns the server
);

CREATE TABLE server_members (
    server_id INT NOT NULL,                -- ID of the server
    user_id INT NOT NULL,                  -- ID of the user
    role VARCHAR(50) NOT NULL,             -- Role of the user in the server (e.g., admin, member)
    PRIMARY KEY (server_id, user_id),      -- Composite primary key (server_id, user_id)
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE,  -- Foreign key to servers table
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE       -- Foreign key to users table
);
