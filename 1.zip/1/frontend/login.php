<?php
session_start();

// If user is already logged in, redirect to chats.php
if (isset($_SESSION['user_id'])) {
    header("Location: chats.php");
    exit;
}

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', '1');

// Connect to the database
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Enable detailed error reporting
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Initialize variables
$username = '';
$error = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];

    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password";
    } else {
        // Prepare the SQL statement
        $stmt = $conn->prepare("SELECT id, username, password, profile_photo FROM `users` WHERE username = ?");
        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }

        // Bind parameters
        $stmt->bind_param("s", $username);

        // Execute the statement
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($id, $db_username, $hashed_password, $profile_photo);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $id;
                $_SESSION['username'] = $db_username;
                $_SESSION['profile_photo'] = $profile_photo;
                header("Location: chats.php");
                exit;
            } else {
                $error = "Invalid username or password";
            }
        } else {
            $error = "Invalid username or password";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login • Orion</title>
    <link href="https://fonts.googleapis.com/css2?family=Grand+Hotel&family=Inter:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3897f0;
            --error: #ed4956;
            --success: #4BB543;
            --border: #dbdbdb;
            --bg: #fafafa;
            --text: #262626;
        }
        body {
            background: var(--bg);
            font-family: 'Inter', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        .login-container {
            width: 100%;
            max-width: 400px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 40px 32px;
            text-align: center;
        }
        .login-logo {
            font-family: 'Grand Hotel', cursive;
            font-size: 2.8rem;
            margin-bottom: 30px;
            color: var(--text);
        }
        .login-form input {
            width: 100%;
            padding: 14px 15px;
            margin-bottom: 18px;
            border: 1px solid var(--border);
            border-radius: 6px;
            font-size: 1.08rem;
        }
        .login-form button {
            width: 100%;
            padding: 14px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 6px;
            font-weight: 600;
            font-size: 1.08rem;
            cursor: pointer;
            margin-bottom: 8px;
        }
        .error {
            color: var(--error);
            margin-bottom: 15px;
        }
        .success {
            color: var(--success);
            margin-bottom: 15px;
        }
        .signup-link {
            margin-top: 20px;
            font-size: 1rem;
        }
        .signup-link a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
        }
        @media (max-width: 500px) {
            .login-container {
                max-width: 95vw;
                padding: 22px 7vw 22px 7vw;
                border-radius: 0;
                box-shadow: none;
                border: none;
            }
            .login-logo {
                font-size: 2.1rem;
                margin-bottom: 20px;
            }
            .login-form input, .login-form button {
                font-size: 1rem;
                padding: 12px 10px;
            }
            .signup-link {
                font-size: 0.98rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-logo">Orion</div>

        <?php if (!empty($success_message)): ?>
            <div class="success"><?= htmlspecialchars($success_message) ?></div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form class="login-form" method="POST">
            <input type="text" name="username" placeholder="Username" value="<?= htmlspecialchars($username) ?>" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Log In</button>
        </form>

        <div class="signup-link">
            Don't have an account? <a href="signup.php">Sign up</a>
        </div>
    </div>
</body>
</html>
