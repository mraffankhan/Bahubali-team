<?php
session_start();
if (!isset($_SESSION['user_id'])) exit;
$user_id = $_SESSION['user_id'];

if (!isset($_GET['username'])) {
    echo json_encode(['users' => []]);
    exit;
}

$username = trim($_GET['username']);
if (strlen($username) < 1) {
    echo json_encode(['users' => []]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "1");
$stmt = $conn->prepare("SELECT id, username, profile_photo FROM users WHERE username LIKE CONCAT(?, '%') AND id != ? LIMIT 10");
$stmt->bind_param("si", $username, $user_id);
$stmt->execute();
$stmt->bind_result($id, $found_username, $profile_photo);

$users = [];
while ($stmt->fetch()) {
    // Check if friend request already sent
    $stmt2 = $conn->prepare("SELECT id FROM friend_requests WHERE sender_id=? AND receiver_id=?");
    $stmt2->bind_param("ii", $user_id, $id);
    $stmt2->execute();
    $stmt2->store_result();
    $requested = $stmt2->num_rows > 0;
    $stmt2->close();

    $users[] = [
        'id' => $id,
        'username' => $found_username,
        'profile_photo' => $profile_photo,
        'requested' => $requested
    ];
}
$stmt->close();
echo json_encode(['users' => $users]);
