<?php
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', '1');

// Connect to database
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
} catch (Exception $e) {
    die("Database error: " . $e->getMessage());
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $username = trim($_POST["username"]);
    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    // Validate username
    if (empty($username)) {
        $errors['username'] = "Username is required";
    } elseif (!preg_match('/^[a-zA-Z0-9_]{4,20}$/', $username)) {
        $errors['username'] = "Username must be 4-20 chars (letters, numbers, _)";
    }

    // Validate email
    if (empty($email)) {
        $errors['email'] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format";
    }

    // Validate password
    if (empty($password)) {
        $errors['password'] = "Password is required";
    } elseif (strlen($password) < 8) {
        $errors['password'] = "Password must be at least 8 characters";
    } elseif (!preg_match('/[A-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $errors['password'] = "Password must contain at least one uppercase letter and one number";
    } elseif ($password !== $confirm_password) {
        $errors['confirm_password'] = "Passwords do not match";
    }

    // Check if username/email exists only if no errors so far
    if (empty($errors)) {
        try {
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $errors['general'] = "Username or Email already taken";
            } else {
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $insert = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
                $insert->bind_param("sss", $username, $email, $hashed);
                
                if ($insert->execute()) {
                    $_SESSION['registration_success'] = true;
                    header("Location: login.php");
                    exit;
                } else {
                    $errors['general'] = "Registration failed. Please try again.";
                }
            }
            $stmt->close();
        } catch (Exception $e) {
            $errors['general'] = "Database error occurred";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up • Orion</title>
    <link href="https://fonts.googleapis.com/css2?family=Grand+Hotel&family=Inter:wght@400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3897f0;
            --error: #ed4956;
            --border: #dbdbdb;
            --bg: #fafafa;
            --text: #262626;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            background: var(--bg);
            font-family: 'Inter', sans-serif;
            color: var(--text);
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-container {
            width: 100%;
            max-width: 400px;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 40px;
            text-align: center;
        }
        
        .login-logo {
            font-family: 'Grand Hotel', cursive;
            font-size: 2.8rem;
            margin-bottom: 30px;
            color: var(--text);
        }
        
        .login-form input {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 15px;
            border: 1px solid var(--border);
            border-radius: 5px;
            font-size: 1rem;
            transition: border 0.3s;
        }
        
        .login-form input:focus {
            outline: none;
            border-color: var(--primary);
        }
        
        .login-form input.error-field {
            border-color: var(--error);
        }
        
        .error-message {
            color: var(--error);
            font-size: 0.85rem;
            margin: -10px 0 15px;
            text-align: left;
        }
        
        .general-error {
            color: var(--error);
            margin-bottom: 15px;
        }
        
        .login-form button {
            width: 100%;
            padding: 12px;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: 500;
            font-size: 1rem;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.3s;
        }
        
        .login-form button:hover {
            background: #2684f0;
        }
        
        .signup-link {
            margin-top: 20px;
            font-size: 0.95rem;
        }
        
        .signup-link a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
        }
        
        .password-hint {
            font-size: 0.8rem;
            color: #8e8e8e;
            text-align: left;
            margin: -10px 0 15px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-logo">Orion</div>
        
        <?php if (!empty($errors['general'])): ?>
            <div class="general-error"><?= htmlspecialchars($errors['general']) ?></div>
        <?php endif; ?>
        
        <form class="login-form" method="POST" novalidate>
            <input type="text" name="username" placeholder="Username" 
                   value="<?= isset($username) ? htmlspecialchars($username) : '' ?>"
                   class="<?= isset($errors['username']) ? 'error-field' : '' ?>" required>
            <?php if (isset($errors['username'])): ?>
                <div class="error-message"><?= htmlspecialchars($errors['username']) ?></div>
            <?php endif; ?>
            
            <input type="email" name="email" placeholder="Email" 
                   value="<?= isset($email) ? htmlspecialchars($email) : '' ?>"
                   class="<?= isset($errors['email']) ? 'error-field' : '' ?>" required>
            <?php if (isset($errors['email'])): ?>
                <div class="error-message"><?= htmlspecialchars($errors['email']) ?></div>
            <?php endif; ?>
            
            <input type="password" name="password" placeholder="Password" 
                   class="<?= isset($errors['password']) ? 'error-field' : '' ?>" required>
            <?php if (isset($errors['password'])): ?>
                <div class="error-message"><?= htmlspecialchars($errors['password']) ?></div>
            <?php else: ?>
                <div class="password-hint">Use 8+ characters with at least one number and uppercase letter</div>
            <?php endif; ?>
            
            <input type="password" name="confirm_password" placeholder="Confirm Password" 
                   class="<?= isset($errors['confirm_password']) ? 'error-field' : '' ?>" required>
            <?php if (isset($errors['confirm_password'])): ?>
                <div class="error-message"><?= htmlspecialchars($errors['confirm_password']) ?></div>
            <?php endif; ?>
            
            <button type="submit">Sign Up</button>
        </form>
        
        <div class="signup-link">
            Already have an account? <a href="login.php">Log in</a>
        </div>
    </div>
    
    <script>
        // Client-side validation for better UX
        document.querySelector('form').addEventListener('submit', function(e) {
            let valid = true;
            const password = document.querySelector('input[name="password"]');
            const confirmPassword = document.querySelector('input[name="confirm_password"]');
            
            // Clear previous error classes
            document.querySelectorAll('.error-field').forEach(el => {
                el.classList.remove('error-field');
            });
            
            // Validate password match
            if (password.value !== confirmPassword.value) {
                confirmPassword.classList.add('error-field');
                document.querySelector('.error-message:last-child').textContent = "Passwords do not match";
                valid = false;
            }
            
            if (!valid) {
                e.preventDefault();
            }
        });
    </script>
</body>
</html>