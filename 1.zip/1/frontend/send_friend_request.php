<?php
session_start();
if (!isset($_SESSION['user_id'])) exit;
$user_id = $_SESSION['user_id'];
$target_id = intval($_POST['user_id'] ?? 0);

if ($target_id && $target_id != $user_id) {
    $conn = new mysqli("localhost", "root", "", "1");
    // Prevent duplicate requests
    $stmt = $conn->prepare("SELECT id FROM friend_requests WHERE sender_id=? AND receiver_id=?");
    $stmt->bind_param("ii", $user_id, $target_id);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows == 0) {
        $stmt->close();
        $stmt2 = $conn->prepare("INSERT INTO friend_requests (sender_id, receiver_id) VALUES (?, ?)");
        $stmt2->bind_param("ii", $user_id, $target_id);
        $stmt2->execute();
        $stmt2->close();
    } else {
        $stmt->close();
    }
}
