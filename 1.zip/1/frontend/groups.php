<?php
session_start();
if (!isset($_SESSION['user_id'])) { $_SESSION['user_id'] = 1; }
$user_id = $_SESSION['user_id'];
$conn = new mysqli("localhost", "root", "", "1");
if ($conn->connect_error) die("DB connection failed");

// --- Helper function to send JSON response ---
function send_json($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

// --- AJAX: Create group ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === 'create_group') {
    $name = trim($_POST['group_name'] ?? '');
    $desc = trim($_POST['group_desc'] ?? '');
    if ($name !== '') {
        $stmt = $conn->prepare("INSERT INTO groups (name, description, created_by) VALUES (?, ?, ?)");
        if (!$stmt) { http_response_code(500); echo "DB error"; exit; }
        $stmt->bind_param("ssi", $name, $desc, $user_id);
        $stmt->execute();
        $group_id = $stmt->insert_id;
        $stmt->close();
        $stmt2 = $conn->prepare("INSERT INTO group_members (group_id, user_id, is_admin, added_by) VALUES (?, ?, 1, ?)");
        if (!$stmt2) { http_response_code(500); echo "DB error"; exit; }
        $stmt2->bind_param("iii", $group_id, $user_id, $user_id);
        $stmt2->execute();
        $stmt2->close();
        echo $group_id;
    } else {
        http_response_code(400);
        echo "Group name required";
    }
    exit;
}

// --- AJAX: Delete group ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === 'delete_group') {
    $gid = intval($_POST['group_id']);
    $admin = $conn->query("SELECT is_admin FROM group_members WHERE group_id=$gid AND user_id=$user_id")->fetch_assoc();
    if ($admin && $admin['is_admin']) {
        $conn->query("DELETE FROM group_messages WHERE group_id=$gid");
        $conn->query("DELETE FROM group_members WHERE group_id=$gid");
        $conn->query("DELETE FROM groups WHERE id=$gid");
        echo "OK";
    } else {
        http_response_code(403);
        echo "Forbidden";
    }
    exit;
}

// --- AJAX: Edit group info ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === 'edit_group') {
    $gid = intval($_POST['group_id']);
    $name = trim($_POST['group_name'] ?? '');
    $desc = trim($_POST['group_desc'] ?? '');
    $admin = $conn->query("SELECT is_admin FROM group_members WHERE group_id=$gid AND user_id=$user_id")->fetch_assoc();
    if ($admin && $admin['is_admin']) {
        $stmt = $conn->prepare("UPDATE groups SET name=?, description=? WHERE id=?");
        if (!$stmt) { http_response_code(500); echo "DB error"; exit; }
        $stmt->bind_param("ssi", $name, $desc, $gid);
        $stmt->execute();
        $stmt->close();
        echo "OK";
    } else {
        http_response_code(403);
        echo "Forbidden";
    }
    exit;
}

// --- AJAX: Add user to group ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === 'add_user_to_group') {
    $gid = intval($_POST['group_id']);
    $uid = intval($_POST['user_id']);
    $admin = $conn->query("SELECT is_admin FROM group_members WHERE group_id=$gid AND user_id=$user_id")->fetch_assoc();
    if ($admin && $admin['is_admin']) {
        $exists = $conn->query("SELECT id FROM group_members WHERE group_id=$gid AND user_id=$uid")->num_rows;
        if (!$exists) {
            $stmt = $conn->prepare("INSERT INTO group_members (group_id, user_id, is_admin, added_by) VALUES (?, ?, 0, ?)");
            if (!$stmt) { http_response_code(500); echo "DB error"; exit; }
            $stmt->bind_param("iii", $gid, $uid, $user_id);
            $stmt->execute();
            $stmt->close();
            echo "OK";
        } else {
            http_response_code(409);
            echo "User already in group";
        }
    } else {
        http_response_code(403);
        echo "Forbidden";
    }
    exit;
}

// --- AJAX: Remove user from group ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === 'remove_user_from_group') {
    $gid = intval($_POST['group_id']);
    $uid = intval($_POST['user_id']);
    $admin = $conn->query("SELECT is_admin FROM group_members WHERE group_id=$gid AND user_id=$user_id")->fetch_assoc();
    if ($admin && $admin['is_admin'] && $uid != $user_id) {
        $stmt = $conn->prepare("DELETE FROM group_members WHERE group_id=? AND user_id=?");
        if (!$stmt) { http_response_code(500); echo "DB error"; exit; }
        $stmt->bind_param("ii", $gid, $uid);
        $stmt->execute();
        $stmt->close();
        echo "OK";
    } else {
        http_response_code(403);
        echo "Forbidden";
    }
    exit;
}

// --- AJAX: Promote/demote user ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === 'set_admin') {
    $gid = intval($_POST['group_id']);
    $uid = intval($_POST['user_id']);
    $is_admin = intval($_POST['is_admin']) ? 1 : 0;
    $admin = $conn->query("SELECT is_admin FROM group_members WHERE group_id=$gid AND user_id=$user_id")->fetch_assoc();
    if ($admin && $admin['is_admin'] && $uid != $user_id) {
        $stmt = $conn->prepare("UPDATE group_members SET is_admin=? WHERE group_id=? AND user_id=?");
        if (!$stmt) { http_response_code(500); echo "DB error"; exit; }
        $stmt->bind_param("iii", $is_admin, $gid, $uid);
        $stmt->execute();
        $stmt->close();
        echo "OK";
    } else {
        http_response_code(403);
        echo "Forbidden";
    }
    exit;
}

// --- AJAX: Get my groups (with description, admin info) ---
if (isset($_GET['ajax']) && $_GET['ajax'] === 'groups') {
    $stmt = $conn->prepare(
        "SELECT g.id, g.name, g.description, g.created_by, 
         (SELECT is_admin FROM group_members WHERE group_id=g.id AND user_id=?) as is_admin
         FROM groups g 
         JOIN group_members m ON g.id=m.group_id 
         WHERE m.user_id=?
         GROUP BY g.id ORDER BY g.id DESC");
    $stmt->bind_param("ii", $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = [];
    while ($g = $result->fetch_assoc()) $data[] = $g;
    $stmt->close();
    send_json($data);
}

// --- AJAX: Get group info (members, admins, etc) ---
if (isset($_GET['ajax']) && $_GET['ajax'] === 'group_info' && isset($_GET['group_id'])) {
    $gid = intval($_GET['group_id']);
    $stmt = $conn->prepare("SELECT id, name, description, created_by FROM groups WHERE id=?");
    $stmt->bind_param("i", $gid);
    $stmt->execute();
    $group = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $members = [];
    $stmt = $conn->prepare(
        "SELECT gm.user_id, u.username, gm.is_admin 
         FROM group_members gm 
         JOIN users u ON gm.user_id=u.id
         WHERE gm.group_id=? ORDER BY u.username ASC");
    $stmt->bind_param("i", $gid);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($m = $res->fetch_assoc()) $members[] = $m;
    $stmt->close();

    $all_users = [];
    $stmt = $conn->prepare(
        "SELECT id, username FROM users WHERE id NOT IN (SELECT user_id FROM group_members WHERE group_id=?) ORDER BY username ASC");
    $stmt->bind_param("i", $gid);
    $stmt->execute();
    $res2 = $stmt->get_result();
    while ($u = $res2->fetch_assoc()) $all_users[] = $u;
    $stmt->close();

    send_json(['group'=>$group, 'members'=>$members, 'all_users'=>$all_users]);
}

// --- AJAX: Fetch messages (with usernames) ---
if (isset($_GET['ajax']) && $_GET['ajax'] === 'messages' && isset($_GET['group_id'])) {
    $gid = intval($_GET['group_id']);
    $stmt = $conn->prepare(
        "SELECT gm.id, gm.sender_id, u.username, gm.message, gm.created_at, gm.deleted_by
         FROM group_messages gm
         JOIN users u ON gm.sender_id = u.id
         WHERE gm.group_id = ?
         ORDER BY gm.created_at ASC");
    $stmt->bind_param("i", $gid);
    $stmt->execute();
    $res = $stmt->get_result();
    $messages = [];
    while ($row = $res->fetch_assoc()) {
        $deleted_by = $row['deleted_by'] ? json_decode($row['deleted_by'], true) : [];
        if ($deleted_by && in_array($user_id, $deleted_by)) continue;
        $messages[] = $row;
    }
    $stmt->close();
    send_json($messages);
}

// --- AJAX: Send message ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === 'send' && isset($_POST['group_id'])) {
    $gid = intval($_POST['group_id']);
    $msg = trim($_POST['msg'] ?? '');
    if ($msg !== '') {
        $stmt = $conn->prepare("INSERT INTO group_messages (group_id, sender_id, message) VALUES (?, ?, ?)");
        if (!$stmt) { http_response_code(500); echo "DB error"; exit; }
        $stmt->bind_param("iis", $gid, $user_id, $msg);
        $stmt->execute();
        $stmt->close();
    } else {
        http_response_code(400);
        echo "Message cannot be empty";
    }
    exit;
}

// --- AJAX: Delete message ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['ajax'] ?? '') === 'delete_msg') {
    $msg_id = intval($_POST['msg_id']);
    $for_everyone = isset($_POST['everyone']) && $_POST['everyone'] == '1';
    $stmt = $conn->prepare("SELECT sender_id, deleted_by FROM group_messages WHERE id=?");
    $stmt->bind_param("i", $msg_id);
    $stmt->execute();
    $msg = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$msg) exit;

    if ($for_everyone && $msg['sender_id'] == $user_id) {
        $stmt = $conn->prepare("UPDATE group_messages SET message='This message was deleted', deleted_by=NULL WHERE id=?");
        $stmt->bind_param("i", $msg_id);
        $stmt->execute();
        $stmt->close();
    } else {
        $deleted_by = $msg['deleted_by'] ? json_decode($msg['deleted_by'], true) : [];
        if (!in_array($user_id, $deleted_by)) $deleted_by[] = $user_id;
        $deleted_json = json_encode($deleted_by);
        $stmt = $conn->prepare("UPDATE group_messages SET deleted_by=? WHERE id=?");
        $stmt->bind_param("si", $deleted_json, $msg_id);
        $stmt->execute();
        $stmt->close();
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
  <title>Mobile Group Chat</title>
  <style>
    /* Reset and base */
    html, body {
      height: 100%;
      margin: 0;
      padding: 0;
      width: 100vw;
      overflow-x: hidden;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #fafafa;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      -webkit-text-size-adjust: 100%;
      -webkit-tap-highlight-color: transparent;
      color: #222;
      -ms-touch-action: manipulation;
      touch-action: manipulation;
      user-select: none;
    }

    a, button {
      -webkit-tap-highlight-color: transparent;
      cursor: pointer;
      user-select: none;
    }

    #container {
      height: 100vh;
      width: 100vw;
      display: flex;
      flex-direction: column;
      background: #fafafa;
    }

    /* Groups list page */
    #groupsListPage {
      flex: 1;
      display: flex;
      flex-direction: column;
      max-width: 400px;
      margin: 0 auto;
      width: 100%;
      box-sizing: border-box;
      border-left: 1px solid #eee;
      border-right: 1px solid #eee;
    }

    #groupsHeader {
      padding: 16px 20px;
      font-weight: 700;
      font-size: 1.3em;
      border-bottom: 1px solid #eee;
      background: #3897f0;
      color: #fff;
      letter-spacing: 1px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      position: relative;
    }

    #groupsHeaderTitle {
      flex: 1;
      text-align: center;
      user-select: none;
    }

    #backToDashboardBtn {
      background: none;
      border: none;
      color: #fff;
      font-size: 1.5em;
      cursor: pointer;
      padding: 6px 12px;
      border-radius: 4px;
      transition: background 0.2s;
      -webkit-tap-highlight-color: transparent;
      user-select: none;
    }
    #backToDashboardBtn:hover {
      background: rgba(255,255,255,0.2);
    }

    #settingsBtn {
      background: none;
      border: none;
      color: #fff;
      font-size: 1.5em;
      cursor: pointer;
      padding: 6px 12px;
      border-radius: 4px;
      transition: background 0.2s;
      user-select: none;
    }
    #settingsBtn:hover {
      background: rgba(255,255,255,0.2);
    }

    #createGroupForm {
      display: flex;
      margin: 8px 20px 8px 20px;
      gap: 8px;
    }

    #createGroupName {
      flex: 1;
      font-size: 1em;
      padding: 8px 12px;
      border-radius: 20px;
      border: 1px solid #ccc;
      outline: none;
      transition: border-color 0.2s;
    }

    #createGroupName:focus {
      border-color: #3897f0;
    }

    #createGroupBtn {
      background: #3897f0;
      color: #fff;
      border: none;
      padding: 8px 16px;
      border-radius: 20px;
      font-weight: 700;
      font-size: 1em;
      cursor: pointer;
      transition: background-color 0.3s;
      user-select: none;
    }
    #createGroupBtn:disabled {
      background: #8ab9f7;
      cursor: not-allowed;
    }
    #createGroupBtn:hover:not(:disabled) {
      background: #2a6cd6;
    }

    #groupsList {
      flex: 1;
      overflow-y: auto;
      background: #fff;
      -webkit-overflow-scrolling: touch;
      border-top: 1px solid #eee;
      box-sizing: border-box;
      max-height: calc(100vh - 120px);
    }

    .group-row {
      padding: 14px 22px;
      border-bottom: 1px solid #f1f1f1;
      font-size: 1.1em;
      cursor: pointer;
      background: #fff;
      transition: background .15s;
      display: flex;
      flex-direction: column;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      user-select: none;
    }

    .group-row:hover,
    .group-row.active {
      background: #e6f0ff;
    }

    .group-row > span:first-child {
      font-weight: 600;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 100%;
      display: block;
    }

    .group-desc {
      color: #888;
      font-size: 0.88em;
      margin-top: 3px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      font-weight: 400;
    }

    /* Chat main */
    #main {
      width: 100vw; 
      height: 100vh;
      display: none;
      flex-direction: column; 
      background: #fafafa;
      max-width: 400px;
      margin: 0 auto;
      border-left: 1px solid #eee;
      border-right: 1px solid #eee;
      box-sizing: border-box;
    }

    #chatHeader {
      background: #3897f0;
      color: #fff;
      font-weight: 700;
      font-size: 1.18em;
      display: flex;
      align-items: center;
      min-height: 56px;
      width: 100%;
      box-sizing: border-box;
      position: relative;
      justify-content: space-between;
      padding: 0 8px;
      user-select: none;
    }

    #backBtn {
      background: none;
      border: none;
      color: #fff;
      font-size: 1.7em;
      cursor: pointer;
      margin-left: 4px;
      margin-right: 8px;
      display: none;
      z-index: 2;
      padding: 6px 8px;
      border-radius: 5px;
      transition: background 0.2s;
    }
    #backBtn:hover {
      background: rgba(255,255,255,0.2);
    }

    #chatHeaderText {
      flex: 1;
      text-align: center;
      margin: 0;
      font-weight: 700;
      font-size: 1.2em;
      user-select: none;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    #headerRightBtns {
      display: flex;
      align-items: center;
      gap: 6px;
      min-width: 56px;
      justify-content: flex-end;
    }

    #groupSettingsBtn, #dashboardBtn {
      background: none;
      border: none;
      color: #fff;
      font-size: 1.5em;
      cursor: pointer;
      z-index: 2;
      padding: 6px 10px;
      border-radius: 5px;
      display: none;
      user-select: none;
      transition: background 0.2s;
    }

    #groupSettingsBtn:hover, #dashboardBtn:hover {
      background: rgba(255,255,255,0.25);
    }

    #chatArea {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 0;
      width: 100%;
      box-sizing: border-box;
      -webkit-overflow-scrolling: touch;
      background: #f8fafd;
      border-top: 1px solid #ddd;
    }

    #chatMessages {
      flex: 1;
      overflow-y: auto;
      padding: 18px 12px 18px 12px;
      min-height: 0;
      display: flex;
      flex-direction: column;
      width: 100%;
      box-sizing: border-box;
    }

    .msg-row {
      display: flex;
      align-items: flex-end;
      margin-bottom: 13px;
      position: relative;
      max-width: 85%;
      word-break: break-word;
      user-select: text;
    }

    .msg.me {
      flex-direction: row-reverse;
      margin-left: auto;
    }

    .msg-bubble {
      display: inline-block;
      padding: 12px 18px;
      border-radius: 18px;
      background: #f0f4fa;
      color: #222;
      font-size: 1rem;
      max-width: 100%;
      box-shadow: 0 2px 8px rgba(56,151,240,0.04);
      position: relative;
      user-select: text;
      overflow-wrap: break-word;
      word-break: break-word;
    }

    .msg.me .msg-bubble {
      background: #3897f0;
      color: #fff;
    }

    .msg-meta {
      font-size: 0.82em;
      color: #888;
      margin: 0 8px;
      margin-top: 2px;
      white-space: nowrap;
      user-select: none;
    }

    .msg-actions {
      display: flex;
      flex-direction: column;
      gap: 2px;
      position: absolute;
      top: 0;
      right: -28px;
      user-select: none;
    }
    .msg.me .msg-actions {
      right: auto;
      left: -28px;
    }

    .msg-actions button {
      background: none;
      border: none;
      color: #888;
      cursor: pointer;
      font-size: 1.1em;
      margin: 0;
      transition: color .2s;
      padding: 2px;
      border-radius: 3px;
      user-select: none;
    }
    .msg-actions button:hover {
      color: #ed4956;
    }

    #chatForm {
      display: flex;
      padding: 12px 12px 12px 12px;
      border-top: 1px solid #ccc;
      background: #fff;
      width: 100%;
      box-sizing: border-box;
    }

    #msgInput {
      flex: 1;
      padding: 12px 16px;
      font-size: 1rem;
      border-radius: 20px;
      border: 1px solid #ccc;
      outline: none;
      user-select: text;
    }

    #sendBtn {
      background: #3897f0;
      color: #fff;
      border: none;
      padding: 12px 20px;
      margin-left: 12px;
      border-radius: 20px;
      cursor: pointer;
      font-weight: 700;
      font-size: 1rem;
      user-select: none;
      transition: background-color 0.3s;
    }
    #sendBtn:disabled {
      background: #8ab9f7;
      cursor: not-allowed;
    }
    #sendBtn:hover:not(:disabled) {
      background-color: #2a6cd6;
    }

    /* Hide scrollbars for webkit */
    ::-webkit-scrollbar {
      width: 0;
      background: transparent;
    }

    /* Group Info Modal */
    #groupInfoModal {
      position: fixed;
      left: 0; top: 0; width: 100vw; height: 100vh;
      background: rgba(0,0,0,0.22);
      display: none;
      align-items: flex-end;
      justify-content: center;
      z-index: 101;
    }
    #groupInfoModal.active {
      display: flex;
    }

    #groupInfoSheet {
      background: #fff;
      border-radius: 18px 18px 0 0;
      padding: 22px 20px 18px 20px;
      box-shadow: 0 6px 32px rgba(56,151,240,0.12);
      width: 100vw;
      max-width: 400px;
      animation: fadeIn .2s;
      position: relative;
      max-height: 85vh;
      overflow-y: auto;
      -webkit-overflow-scrolling: touch;
    }

    #groupInfoModal .close-modal {
      position: absolute;
      top: 12px; right: 14px;
      background: none;
      border: none;
      font-size: 2em;
      color: #aaa;
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 6px;
      transition: color 0.2s;
      user-select: none;
    }
    #groupInfoModal .close-modal:hover {
      color: #3897f0;
    }

    #groupInfoForm input, #groupInfoForm textarea {
      width: 100%;
      padding: 12px 14px;
      border-radius: 10px;
      border: 1px solid #dbdbdb;
      font-size: 1em;
      margin-bottom: 10px;
      outline: none;
      resize: vertical;
      box-sizing: border-box;
      user-select: text;
    }

    #groupInfoForm button[type="submit"] {
      margin-top: 10px;
      width: 100%;
      padding: 11px 0;
      background: #3897f0;
      color: #fff;
      border: none;
      border-radius: 20px;
      font-weight: 700;
      font-size: 1em;
      cursor: pointer;
      transition: background-color 0.3s;
      user-select: none;
    }
    #groupInfoForm button[type="submit"]:hover {
      background-color: #2a6cd6;
    }

    .group-members-list {
      margin: 18px 0 0 0;
      max-height: 240px;
      overflow-y: auto;
      border-top: 1px solid #eee;
      user-select: none;
    }

    .group-member-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 7px 0;
      border-bottom: 1px solid #f2f2f2;
      font-size: 0.95em;
    }

    .group-member-row span {
      display: flex;
      align-items: center;
      flex-wrap: nowrap;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 70%;
    }

    .group-member-row span > .admin-badge {
      background: #3897f0;
      color: #fff;
      font-size: 0.85em;
      border-radius: 7px;
      padding: 2px 7px;
      margin-left: 8px;
      user-select: none;
    }

    .group-member-row span > .self-badge {
      font-weight: 700;
      color: #555;
      margin-left: 6px;
      user-select: none;
    }

    .group-member-actions button {
      background: none;
      border: none;
      color: #888;
      cursor: pointer;
      font-size: 1.1em;
      margin-left: 8px;
      transition: color 0.2s;
      padding: 4px 6px;
      border-radius: 4px;
      user-select: none;
    }
    .group-member-actions button:hover {
      color: #ed4956;
      background: #ffe6e6;
    }

    .add-user-select {
      width: 100%;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid #dbdbdb;
      font-size: 1em;
      margin-bottom: 10px;
      appearance: none;
      -webkit-appearance: none;
      -moz-appearance: none;
      background: url("data:image/svg+xml;charset=US-ASCII,%3csvg fill='%23888' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M7 10l5 5 5-5z'/%3e%3c/svg%3e") no-repeat right 12px center;
      background-size: 16px 16px;
      cursor: pointer;
      user-select: none;
    }

    .add-user-btn {
      width: 100%;
      padding: 11px 0;
      background: #3897f0;
      color: #fff;
      border: none;
      border-radius: 20px;
      font-weight: 700;
      font-size: 1em;
      cursor: pointer;
      margin-bottom: 10px;
      user-select: none;
      transition: background 0.3s;
    }
    .add-user-btn:active {
      background: #2a6cd6;
    }
    .add-user-btn:disabled {
      background: #8ab9f7;
      cursor: not-allowed;
    }

    .delete-group-btn {
      width: 100%;
      padding: 11px 0;
      background: #ed4956;
      color: #fff;
      border: none;
      border-radius: 20px;
      font-weight: 700;
      font-size: 1em;
      cursor: pointer;
      margin-top: 16px;
      user-select: none;
      transition: background 0.3s;
    }
    .delete-group-btn:active {
      background: #b91d2b;
    }

    /* Animations */
    @keyframes fadeIn {
      from {opacity: 0;}
      to {opacity: 1;}
    }

    /* Responsive adjustments */
    @media (max-width: 400px) {
      body {
        font-size: 14px;
      }

      #groupsHeader, #chatHeader {
        font-size: 1.1em;
      }
    }
  </style>
</head>
<body>
<div id="container">
  <div id="groupsListPage">
    <div id="groupsHeader">
      <button id="backToDashboardBtn" title="Home" onclick="window.location='dashboard.php'">&#8962;</button>
      <div id="groupsHeaderTitle">My Groups</div>
      <button id="settingsBtn" title="Settings" onclick="alert('Sidebar settings can be extended here!')">&#9881;</button>
    </div>

    <form id="createGroupForm" onsubmit="return createGroup();">
      <input type="text" id="createGroupName" placeholder="New group name" autocomplete="off" required minlength="1" maxlength="50" />
      <button type="submit" id="createGroupBtn" disabled>Create</button>
    </form>

    <div id="groupsList" aria-live="polite" aria-relevant="all" role="list"></div>
  </div>

  <div id="main" aria-live="polite" aria-relevant="all" role="main">
    <div id="chatHeader" role="banner">
      <button id="backBtn" aria-label="Back to groups list" title="Back to groups list" onclick="showGroupsList()">&larr;</button>
      <span id="chatHeaderText" aria-live="polite" aria-atomic="true">Select a group</span>
      <span id="headerRightBtns">
        <button id="dashboardBtn" title="Dashboard" onclick="showGroupsList()" aria-label="Dashboard">&#8962;</button>
        <button id="groupSettingsBtn" title="Group Settings" aria-label="Group Settings">&#9881;</button>
      </span>
    </div>
    <div id="chatArea" style="display:none;">
      <div id="chatMessages" role="log" aria-live="polite" aria-relevant="additions"></div>
      <form id="chatForm" onsubmit="return sendMessage();" aria-label="Send message form">
        <input type="text" id="msgInput" placeholder="Type a message..." autocomplete="off" required aria-required="true" aria-label="Message input" />
        <button type="submit" id="sendBtn" disabled aria-disabled="true">Send</button>
      </form>
    </div>
  </div>
</div>

<!-- Group Info Modal -->
<div id="groupInfoModal" role="dialog" aria-modal="true" aria-labelledby="groupModalTitle" aria-describedby="groupModalDesc">
  <div id="groupInfoSheet">
    <button type="button" class="close-modal" aria-label="Close group info modal" onclick="closeGroupInfoModal()">&times;</button>
    <form id="groupInfoForm" style="display:none;" onsubmit="return saveGroupInfo();" aria-label="Edit group info">
      <label for="groupInfoName">Group Name</label>
      <input type="text" id="groupInfoName" required aria-required="true" maxlength="50" />

      <label for="groupInfoDesc">Description</label>
      <textarea id="groupInfoDesc" rows="2" maxlength="255" aria-label="Group description"></textarea>

      <button type="submit" aria-label="Save group info">Save</button>
    </form>
    <div id="groupInfoView" style="user-select:none;"></div>
    <div id="groupAddUser" style="margin-top:18px;"></div>
    <div class="group-members-list" id="groupMembersList"></div>
    <button class="delete-group-btn" id="deleteGroupBtn" style="display:none;" aria-label="Delete group" onclick="deleteGroupFromInfo();return false;">Delete Group</button>
  </div>
</div>

<script>
const myId = <?= json_encode($user_id) ?>;
let groups = [];
let currentGroup = null;
let poller = null;
let isCurrentUserAdmin = false;

// Utility: Escape HTML to prevent XSS
function escapeHtml(text) {
    if (!text) return '';
    return text.replace(/[&<>"']/g, m => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[m]);
}

// Load groups and render list
function loadGroups(callback) {
    fetch('groups.php?ajax=groups')
        .then(res => res.json())
        .then(data => {
            groups = data;
            let html = '';
            if (data.length === 0) {
                html = '<div style="text-align:center;color:#888;margin-top:40px;">No groups yet. Create one!</div>';
            } else {
                data.forEach(g => {
                    const desc = g.description ? `<span class="group-desc">${escapeHtml(g.description)}</span>` : '';
                    html += `<div class="group-row" role="listitem" tabindex="0" data-id="${g.id}" onclick="selectGroup(${g.id})" onkeydown="if(event.key==='Enter'||event.key===' ')selectGroup(${g.id});">
                        <span>${escapeHtml(g.name)}</span>
                        ${desc}
                    </div>`;
                });
            }
            document.getElementById('groupsList').innerHTML = html;
            if (callback) callback();
        })
        .catch(err => {
            console.error('Failed to load groups', err);
            document.getElementById('groupsList').innerHTML = '<div style="text-align:center;color:#ed4956;margin-top:40px;">Failed to load groups</div>';
        });
}
loadGroups();
setInterval(loadGroups, 16000);

// Enable/disable create group button
const createGroupName = document.getElementById('createGroupName');
const createGroupBtn = document.getElementById('createGroupBtn');

createGroupName.addEventListener('input', () => {
    createGroupBtn.disabled = !createGroupName.value.trim();
});

// Create new group
function createGroup() {
    const name = createGroupName.value.trim();
    if (!name) return false;
    createGroupBtn.disabled = true;

    fetch('groups.php', {
        method: 'POST',
        headers: {'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ajax: 'create_group', group_name: name, group_desc: ''})
    }).then(res => res.text())
    .then(resp => {
        if (!isNaN(resp) && +resp > 0) {
            createGroupName.value = '';
            createGroupBtn.disabled = true;
            loadGroups(() => selectGroup(+resp));
        } else {
            alert('Failed to create group: ' + resp);
        }
    }).catch(() => alert('Network error creating group'))
    .finally(() => createGroupBtn.disabled = false);

    return false;
}

// Select a group: open chat, hide groups list
function selectGroup(group_id) {
    currentGroup = groups.find(g => g.id == group_id);
    if (!currentGroup) return;

    document.getElementById('groupsListPage').style.display = 'none';
    document.getElementById('main').style.display = 'flex';
    document.getElementById('chatHeaderText').textContent = currentGroup.name;
    document.getElementById('chatArea').style.display = 'flex';
    document.querySelectorAll('.group-row').forEach(el => el.classList.remove('active'));
    let sel = document.querySelector(`.group-row[data-id="${group_id}"]`);
    if (sel) sel.classList.add('active');
    if (poller) clearInterval(poller);
    loadMessages(true);
    poller = setInterval(loadMessages, 2000);
    document.getElementById('backBtn').style.display = 'inline';
    document.getElementById('dashboardBtn').style.display = 'inline';
    document.getElementById('groupSettingsBtn').style.display = 'inline';
    msgInput.focus();
}

// Show groups list (dashboard), hide chat
function showGroupsList() {
    document.getElementById('groupsListPage').style.display = 'flex';
    document.getElementById('main').style.display = 'none';
    document.getElementById('chatArea').style.display = 'none';
    document.getElementById('chatHeaderText').textContent = 'Select a group';
    document.getElementById('backBtn').style.display = 'none';
    document.getElementById('groupSettingsBtn').style.display = 'none';
    document.getElementById('dashboardBtn').style.display = 'none';
    if (poller) clearInterval(poller);
    currentGroup = null;
}

// Load chat messages and scroll to bottom optionally
const chatMessages = document.getElementById('chatMessages');
function loadMessages(scrollToBottom = false) {
    if (!currentGroup) return;
    fetch('groups.php?ajax=messages&group_id=' + currentGroup.id)
        .then(res => res.json())
        .then(data => {
            let html = '';
            if (!Array.isArray(data) || data.length === 0) {
                html = '<div style="color:#888;text-align:center;margin-top:40px;">No messages yet.</div>';
            } else {
                data.forEach(msg => {
                    let isMe = msg.sender_id == myId;
                    const safeMsg = escapeHtml(msg.message);
                    const timeString = msg.created_at.substr(11,5);
                    html += `<div class="msg-row${isMe ? ' me' : ''} msg" aria-label="${isMe ? 'You' : escapeHtml(msg.username)} said at ${timeString}">
                        <div class="msg-bubble">${safeMsg}</div>
                        <div class="msg-meta">${escapeHtml(msg.username)} · ${timeString}</div>
                        <div class="msg-actions">
                            <button onclick="deleteMsg(${msg.id}, false);return false;" title="Delete for me" aria-label="Delete message for me">&#128465;</button>
                            ${isMe ? `<button onclick="deleteMsg(${msg.id}, true);return false;" title="Delete for everyone" aria-label="Delete message for everyone" style="color:#ed4956;">&#128465;&#65039;</button>` : ''}
                        </div>
                    </div>`;
                });
            }
            chatMessages.innerHTML = html;
            if (scrollToBottom) {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
        })
        .catch(() => {
            chatMessages.innerHTML = '<div style="color:#ed4956;text-align:center;margin-top:40px;">Failed to load messages</div>';
        });
}

// Send message form controls
const msgInput = document.getElementById('msgInput');
const sendBtn = document.getElementById('sendBtn');

msgInput.addEventListener('input', () => {
    sendBtn.disabled = msgInput.value.trim() === '';
    sendBtn.setAttribute('aria-disabled', sendBtn.disabled ? 'true' : 'false');
});

// Send a new message
function sendMessage() {
    const msg = msgInput.value.trim();
    if (!msg || !currentGroup) return false;
    sendBtn.disabled = true;
    sendBtn.setAttribute('aria-disabled', 'true');
    fetch('groups.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ ajax: 'send', group_id: currentGroup.id, msg })
    }).then(res => {
        if (!res.ok) throw new Error('Failed to send message');
        return res.text();
    }).then(() => {
        msgInput.value = '';
        sendBtn.disabled = true;
        sendBtn.setAttribute('aria-disabled', 'true');
        loadMessages(true);
    }).catch(() => alert('Network error sending message'));
    return false;
}

// Delete message (own or everyone)
function deleteMsg(msg_id, everyone) {
    if (everyone && !confirm('Delete this message for everyone?')) return;
    fetch('groups.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ ajax: 'delete_msg', msg_id, everyone: everyone ? 1 : 0 })
    }).then(res => {
        if (!res.ok) throw new Error('Failed to delete message');
        loadMessages(true);
    }).catch(() => alert('Network error deleting message'));
}

// Group info modal logic
const groupInfoModal = document.getElementById('groupInfoModal');
const groupInfoForm = document.getElementById('groupInfoForm');
const groupInfoName = document.getElementById('groupInfoName');
const groupInfoDesc = document.getElementById('groupInfoDesc');
const groupInfoView = document.getElementById('groupInfoView');
const groupAddUser = document.getElementById('groupAddUser');
const groupMembersList = document.getElementById('groupMembersList');
const deleteGroupBtn = document.getElementById('deleteGroupBtn');
let groupInfoMembers = [];
let groupInfoAllUsers = [];
let groupInfoData = null;

document.getElementById('groupSettingsBtn').onclick = openGroupInfoModal;

function openGroupInfoModal() {
    if (!currentGroup) return;
    fetch('groups.php?ajax=group_info&group_id=' + currentGroup.id)
        .then(res => res.json())
        .then(data => {
            groupInfoData = data.group;
            groupInfoMembers = data.members;
            groupInfoAllUsers = data.all_users;
            isCurrentUserAdmin = !!groupInfoMembers.find(m => m.user_id == myId && m.is_admin == 1);
            groupInfoModal.classList.add('active');
            renderGroupInfo();
        })
        .catch(() => alert('Failed to load group info'));
}

function closeGroupInfoModal() {
    groupInfoModal.classList.remove('active');
}

groupInfoModal.onclick = function(e) {
    if (e.target === groupInfoModal) closeGroupInfoModal();
};

function renderGroupInfo() {
    if (!groupInfoData) return;
    if (isCurrentUserAdmin) {
        groupInfoForm.style.display = '';
        groupInfoName.value = groupInfoData.name;
        groupInfoDesc.value = groupInfoData.description || '';
        groupInfoView.innerHTML = '';
        deleteGroupBtn.style.display = '';
    } else {
        groupInfoForm.style.display = 'none';
        groupInfoView.innerHTML = `<div id="groupModalTitle" style="font-size:1.1em;font-weight:700;user-select:none;">${escapeHtml(groupInfoData.name)}</div>
            ${groupInfoData.description ? `<div id="groupModalDesc" style="color:#888;margin-top:5px;user-select:none;">${escapeHtml(groupInfoData.description)}</div>` : ''}`;
        deleteGroupBtn.style.display = 'none';
    }
    if (isCurrentUserAdmin) {
        let html = '';
        if (groupInfoAllUsers.length > 0) {
            html += `<select class="add-user-select" id="addUserSelect" aria-label="Add user to group">
                <option value="">Add user to group</option>`;
            groupInfoAllUsers.forEach(u => {
                html += `<option value="${u.id}">${escapeHtml(u.username)}</option>`;
            });
            html += `</select>
            <button class="add-user-btn" id="addUserBtn" aria-label="Add selected user to group" onclick="addUserToGroup();return false;" disabled>Add User</button>`;
        } else {
            html += `<div style="color:#888;user-select:none;">No users left to add.</div>`;
        }
        groupAddUser.innerHTML = html;
        // Add event listener for select + button enabling
        const addUserSelect = document.getElementById('addUserSelect');
        const addUserBtn = document.getElementById('addUserBtn');
        if (addUserSelect && addUserBtn) {
            addUserSelect.addEventListener('change', () => {
                addUserBtn.disabled = !addUserSelect.value;
            });
        }
    } else {
        groupAddUser.innerHTML = '';
    }

    let html = '';
    groupInfoMembers.forEach(m => {
        html += `<div class="group-member-row">
            <span>${escapeHtml(m.username)}${m.is_admin == 1 ? '<span class="admin-badge">Admin</span>' : ''}${m.user_id == myId ? '<span class="self-badge">(You)</span>' : ''}</span>
            <span class="group-member-actions">`;
        if (isCurrentUserAdmin && m.user_id != myId) {
            html += m.is_admin == 1
                ? `<button title="Dismiss admin" aria-label="Dismiss admin from ${escapeHtml(m.username)}" onclick="setAdmin(${m.user_id},0);return false;">&#128683;</button>`
                : `<button title="Make admin" aria-label="Make admin ${escapeHtml(m.username)}" onclick="setAdmin(${m.user_id},1);return false;">&#128081;</button>`;
            html += `<button title="Remove user" aria-label="Remove user ${escapeHtml(m.username)} from group" onclick="removeUserFromGroup(${m.user_id});return false;">&#10060;</button>`;
        }
        html += `</span></div>`;
    });
    groupMembersList.innerHTML = html;
}

function saveGroupInfo() {
    if (!groupInfoName.value.trim()) {
      alert('Group name cannot be empty');
      groupInfoName.focus();
      return false;
    }
    fetch('groups.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            ajax: 'edit_group',
            group_id: currentGroup.id,
            group_name: groupInfoName.value.trim(),
            group_desc: groupInfoDesc.value.trim()
        })
    }).then(res => res.text())
    .then(resp => {
        if (resp === 'OK') {
            groupInfoData.name = groupInfoName.value.trim();
            groupInfoData.description = groupInfoDesc.value.trim();
            document.getElementById('chatHeaderText').textContent = groupInfoName.value.trim();
            loadGroups();
            renderGroupInfo();
        } else {
            alert('Failed to save group info: ' + resp);
        }
    }).catch(() => alert('Network error saving group info'));
    return false;
}

function addUserToGroup() {
    const select = document.getElementById('addUserSelect');
    if (!select || !select.value) return;
    const uid = select.value;
    const addUserBtn = document.getElementById('addUserBtn');
    if (addUserBtn) addUserBtn.disabled = true;
    fetch('groups.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            ajax: 'add_user_to_group',
            group_id: currentGroup.id,
            user_id: uid
        })
    }).then(res => res.text())
    .then(resp => {
        if (resp === 'OK') {
            openGroupInfoModal();
        } else {
            alert('Could not add user: ' + resp);
        }
    }).catch(() => alert('Network error adding user'))
    .finally(() => {
        if (addUserBtn) addUserBtn.disabled = false;
    });
}

function removeUserFromGroup(uid) {
    if (!confirm('Remove this user from the group?')) return;
    fetch('groups.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            ajax: 'remove_user_from_group',
            group_id: currentGroup.id,
            user_id: uid
        })
    }).then(res => res.text())
    .then(resp => {
        if (resp === 'OK') {
            openGroupInfoModal();
        } else {
            alert('Could not remove user: ' + resp);
        }
    }).catch(() => alert('Network error removing user'));
}

function setAdmin(uid, is_admin) {
    fetch('groups.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
            ajax: 'set_admin',
            group_id: currentGroup.id,
            user_id: uid,
            is_admin: is_admin
        })
    }).then(res => res.text())
    .then(resp => {
        if (resp === 'OK') {
            openGroupInfoModal();
        } else {
            alert('Could not change admin status: ' + resp);
        }
    }).catch(() => alert('Network error changing admin status'));
}

function deleteGroupFromInfo() {
    if (!confirm('Delete this group? This action cannot be undone.')) return;
    fetch('groups.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ ajax: 'delete_group', group_id: currentGroup.id })
    }).then(res => res.text())
    .then(resp => {
        if (resp === 'OK') {
            closeGroupInfoModal();
            loadGroups();
            showGroupsList();
        } else {
            alert('Failed to delete group: ' + resp);
        }
    }).catch(() => alert('Network error deleting group'));
}
</script>
</body>
</html>

