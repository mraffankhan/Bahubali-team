<!DOCTYPE html>
<html>
<head>
  <title>Community Coming Soon</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      min-height: 100vh;
      background: #222;
    }
    .coming-soon-overlay {
      position: fixed;
      top: 0; left: 0; right: 0; bottom: 0;
      width: 100vw; height: 100vh;
      z-index: 9999;
      display: flex;
      align-items: center;
      justify-content: center;
      backdrop-filter: blur(8px);
      background: rgba(0,0,0,0.4);
    }
    .coming-soon-message {
      color: #ff2222;
      font-size: 2.5em;
      font-weight: bold;
      background: rgba(255,255,255,0.07);
      border-radius: 18px;
      padding: 48px 60px;
      box-shadow: 0 4px 32px rgba(0,0,0,0.2);
      text-align: center;
      border: 2px solid #ff2222;
      letter-spacing: 1.5px;
      text-shadow: 0 2px 8px #fff2;
      font-family: Arial, sans-serif;
    }
    .back-btn {
      position: fixed;
      top: 28px;
      right: 40px;
      z-index: 10000;
      background: #fff;
      color: #ff2222;
      border: 2px solid #ff2222;
      border-radius: 8px;
      padding: 10px 22px;
      font-size: 1.1em;
      font-weight: bold;
      text-decoration: none;
      transition: background 0.2s, color 0.2s;
      box-shadow: 0 2px 12px rgba(0,0,0,0.10);
      letter-spacing: 0.5px;
    }
    .back-btn:hover {
      background: #ff2222;
      color: #fff;
    }
    @media (max-width: 600px) {
      .coming-soon-message { font-size: 1.3em; padding: 18px 10px; }
      .back-btn { top: 12px; right: 10px; padding: 7px 13px; font-size: 0.95em; }
    }
  </style>
</head>
<body>
  <a href="dashboard.php" class="back-btn">Back to Dashboard</a>
  <div class="coming-soon-overlay">
    <div class="coming-soon-message">
      <h1>ORION is Under Maintenance</h1>
        <p>We're currently working on some updates to improve your experience.</p>
        <p>We apologize for the inconvenience. Please check back later.</p>
    </div>
  </div>
</body>
</html>
