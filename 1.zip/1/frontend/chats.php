<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

// DB connection
$conn = new mysqli("localhost", "root", "", "1");
if ($conn->connect_error) die("DB connection failed: " . $conn->connect_error);

// Get current user data (with error checking)
$user_query = $conn->prepare("SELECT username, profile_photo FROM users WHERE id = ?");
if (!$user_query) die("Prepare failed: " . $conn->error);
$user_query->bind_param("i", $user_id);
if (!$user_query->execute()) die("Execute failed: " . $user_query->error);
$user_result = $user_query->get_result();
$current_user = $user_result->fetch_assoc();
$user_query->close();

if (!$current_user) die("User not found. Please log in again.");

// Handle AJAX requests for messages
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax'])) {
    header('Content-Type: application/json');
    if ($_POST['ajax'] === 'send') {
        $to = intval($_POST['to']);
        $msg = trim($_POST['msg']);
        if ($msg !== '' && $to && $to != $user_id) {
            $stmt = $conn->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
            if (!$stmt) die("Prepare failed: " . $conn->error);
            $stmt->bind_param("iis", $user_id, $to, $msg);
            if (!$stmt->execute()) die("Execute failed: " . $stmt->error);
            $stmt->close();
            echo json_encode(['status' => 'success']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Invalid message']);
        }
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    if ($_GET['ajax'] === 'messages') {
        $to = intval($_GET['to']);
        $stmt = $conn->prepare(
            "SELECT m.*, u.username as sender, u.profile_pic as sender_pic
             FROM messages m
             JOIN users u ON m.sender_id=u.id
             WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)
             ORDER BY m.created_at ASC"
        );
        if (!$stmt) die("Prepare failed: " . $conn->error);
        $stmt->bind_param("iiii", $user_id, $to, $to, $user_id);
        if (!$stmt->execute()) die("Execute failed: " . $stmt->error);
        $res = $stmt->get_result();
        $messages = [];
        while($row = $res->fetch_assoc()) {
            $messages[] = [
                'id' => $row['id'],
                'sender' => $row['sender'],
                'sender_id' => $row['sender_id'],
                'profile_pic' => $row['sender_pic'],
                'message' => htmlspecialchars($row['message']),
                'created_at' => $row['created_at']
            ];
        }
        $stmt->close();
        echo json_encode($messages);
        exit;
    }
    if ($_GET['ajax'] === 'users') {
        $res = $conn->query("SELECT id, username, profile_photo FROM users WHERE id != $user_id ORDER BY username ASC");
        if (!$res) die("Query failed: " . $conn->error);
        $users = [];
        while($row = $res->fetch_assoc()) {
            $msgRes = $conn->query(
                "SELECT message, created_at, sender_id 
                 FROM messages 
                 WHERE (sender_id=$user_id AND receiver_id={$row['id']})
                    OR (sender_id={$row['id']} AND receiver_id=$user_id)
                 ORDER BY created_at DESC 
                 LIMIT 1"
            );
            if (!$msgRes) die("Query failed: " . $conn->error);
            $lastMsg = $msgRes->fetch_assoc();
            $users[] = [
                'id' => $row['id'],
                'username' => $row['username'],
                'profile_photo' => $row['profile_photo'],
                'last_message' => $lastMsg ? [
                    'text' => htmlspecialchars($lastMsg['message']),
                    'time' => $lastMsg['created_at'],
                    'is_me' => $lastMsg['sender_id'] == $user_id
                ] : null
            ];
        }
        echo json_encode($users);
        exit;
    }
}

// Get all users for sidebar
$users = $conn->query("SELECT id, username, profile_photo FROM users WHERE id != $user_id ORDER BY username ASC");
if (!$users) die("Query failed: " . $conn->error);
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat App</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary: #6C5CE7;
            --primary-dark: #5649C0;
            --primary-light: #8577EF;
            --bg: #f5f6fa;
            --text: #2d3436;
            --text-light: #636e72;
            --border: #e9edef;
            --chat-bg: #f1f3f6;
            --msg-in: #ffffff;
            --msg-out: #e1d8ff;
        }
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Helvetica, Arial, sans-serif;
        }
        body {
            background: var(--bg);
            height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .top-nav {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            background: white;
            border-bottom: 1px solid var(--border);
        }
        .profile-section {
            display: flex;
            align-items: center;
            cursor: pointer;
            text-decoration: none;
            color: var(--text);
        }
        .profile-pic {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .username {
            font-weight: 600;
            font-size: 1.1rem;
        }
        .main-content {
            flex: 1;
            display: flex;
            overflow: hidden;
        }
        .sidebar {
            width: 350px;
            background: white;
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            height: 100%;
        }
        .search-bar {
            padding: 10px 15px;
            border-bottom: 1px solid var(--border);
        }
        .search-input {
            width: 100%;
            padding: 8px 15px;
            border-radius: 20px;
            border: 1px solid var(--border);
            outline: none;
            font-size: 0.9rem;
        }
        .user-list {
            flex: 1;
            overflow-y: auto;
        }
        .user-item {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            cursor: pointer;
            border-bottom: 1px solid var(--border);
            transition: background 0.2s;
        }
        .user-item:hover {
            background: #f9f9f9;
        }
        .user-item.active {
            background: var(--chat-bg);
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 12px;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .user-info {
            flex: 1;
            min-width: 0;
        }
        .user-name {
            font-weight: 600;
            margin-bottom: 3px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .user-last-msg {
            font-size: 0.85rem;
            color: var(--text-light);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .msg-time {
            font-size: 0.75rem;
            color: var(--text-light);
        }
        .chat-area {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: var(--chat-bg);
        }
        .chat-header {
            padding: 15px 20px;
            background: white;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
        }
        .chat-user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 12px;
            background: var(--primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        .chat-username {
            font-weight: 600;
            font-size: 1.1rem;
        }
        .chat-status {
            font-size: 0.8rem;
            color: var(--text-light);
            margin-top: 2px;
        }
        .chat-controls {
            margin-left: auto;
            display: flex;
            gap: 15px;
        }
        .chat-btn {
            background: none;
            border: none;
            font-size: 1.2rem;
            color: var(--primary);
            cursor: pointer;
        }
        .messages-container {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4AkEEjEXi4x8LQAAAB1pVFh0Q29tbWVudAAAAAAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAAANElEQVQ4y2NgGAXDFmzatMmKAQ38f2QYNYwZRg0bRg0bNQwZRg0bNQwZRg0bBgAAVQYF/0QbLpQAAAAASUVORK5CYII=');
            background-attachment: fixed;
        }
        .message-row {
            display: flex;
            margin-bottom: 10px;
        }
        .message-row.me {
            justify-content: flex-end;
        }
        .message-bubble {
            max-width: 70%;
            padding: 10px 15px;
            border-radius: 18px;
            font-size: 0.95rem;
            line-height: 1.4;
            word-break: break-word;
            box-shadow: 0 1px 0.5px rgba(0,0,0,0.1);
        }
        .message-row.them .message-bubble {
            background: var(--msg-in);
            border-top-left-radius: 5px;
        }
        .message-row.me .message-bubble {
            background: var(--msg-out);
            border-top-right-radius: 5px;
        }
        .message-meta {
            display: flex;
            justify-content: flex-end;
            font-size: 0.7rem;
            color: var(--text-light);
            margin-top: 5px;
            gap: 5px;
        }
        .input-area {
            padding: 10px 15px;
            background: white;
            border-top: 1px solid var(--border);
            display: flex;
            align-items: center;
        }
        .message-input {
            flex: 1;
            padding: 10px 15px;
            border-radius: 20px;
            border: 1px solid var(--border);
            outline: none;
            resize: none;
            max-height: 100px;
            font-size: 0.95rem;
        }
        .send-btn {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary);
            color: white;
            border: none;
            margin-left: 10px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .send-btn:disabled {
            opacity: 0.7;
            cursor: not-allowed;
        }
        .bottom-nav {
            display: flex;
            background: white;
            border-top: 1px solid var(--border);
        }
        .nav-btn {
            flex: 1;
            padding: 15px 10px;
            text-align: center;
            color: var(--text-light);
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.2s;
        }
        .nav-btn.active {
            color: var(--primary);
        }
        .nav-btn i {
            display: block;
            font-size: 1.2rem;
            margin-bottom: 5px;
        }
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            color: var(--text-light);
            text-align: center;
            padding: 20px;
        }
        .empty-icon {
            font-size: 3rem;
            margin-bottom: 15px;
            color: #ccc;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                position: absolute;
                top: 0;
                left: 0;
                bottom: 0;
                z-index: 10;
            }
            .chat-area {
                display: none;
            }
            .chat-area.active {
                display: flex;
            }
            .sidebar.hidden {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Top Navigation -->
<div class="top-nav">
    <a href="profile.php" class="profile-section">
        <?php if (isset($current_user) && $current_user): ?>
            <?php if (!empty($current_user['profile_photo'])): ?>
                <img src="uploads/<?= htmlspecialchars($current_user['profile_photo']) ?>" class="profile-photo" alt="Profile">
            <?php else: ?>
                <div class="profile-photo"><?= strtoupper($current_user['username'][0]) ?></div>
            <?php endif; ?>
            <div class="username"><?= htmlspecialchars($current_user['username']) ?></div>
        <?php else: ?>
            <div class="profile-photo">?</div>
            <div class="username">Guest</div>
        <?php endif; ?>
    </a>
</div>


    <!-- Main Content -->
    <div class="main-content">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="search-bar">
                <input type="text" class="search-input" placeholder="Search...">
            </div>

            <div class="user-list" id="userList">
                <?php while($user = $users->fetch_assoc()): 
                    // Get last message
                    $msgRes = $conn->query(
                        "SELECT message, created_at, sender_id 
                         FROM messages 
                         WHERE (sender_id=$user_id AND receiver_id={$user['id']})
                            OR (sender_id={$user['id']} AND receiver_id=$user_id)
                         ORDER BY created_at DESC 
                         LIMIT 1"
                    );
                    $lastMsg = $msgRes->fetch_assoc();
                ?>
                    <div class="user-item" data-id="<?= $user['id'] ?>" data-username="<?= htmlspecialchars($user['username']) ?>" data-profile="<?= htmlspecialchars($user['profile_pic']) ?>">
                        <?php if ($user['profile_pic']): ?>
                            <img src="uploads/<?= htmlspecialchars($user['profile_pic']) ?>" class="user-avatar" alt="<?= htmlspecialchars($user['username']) ?>">
                        <?php else: ?>
                            <div class="user-avatar"><?= strtoupper($user['username'][0]) ?></div>
                        <?php endif; ?>
                        <div class="user-info">
                            <div class="user-name"><?= htmlspecialchars($user['username']) ?></div>
                            <?php if ($lastMsg): ?>
                                <div class="user-last-msg"><?= htmlspecialchars($lastMsg['message']) ?></div>
                                <div class="msg-time"><?= $lastMsg['created_at'] ?></div>
                            <?php else: ?>
                                <div class="user-last-msg">No messages yet</div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="chat-area" id="chatArea">
            <div class="chat-header">
                <div class="chat-user-avatar" id="chatUserAvatar"></div>
                <div>
                    <div class="chat-username" id="chatUsername"></div>
                    <div class="chat-status">Online</div>
                </div>
                <div class="chat-controls">
                    <button class="chat-btn"><i class="fas fa-phone"></i></button>
                    <button class="chat-btn"><i class="fas fa-video"></i></button>
                </div>
            </div>
            <div class="messages-container" id="messagesContainer">
                <div class="empty-state">
                    <div class="empty-icon"><i class="fas fa-comment-alt"></i></div>
                    <h3>Select a chat</h3>
                    <p>Choose a user from the sidebar to start chatting</p>
                </div>
            </div>
            <div class="input-area">
                <textarea class="message-input" id="messageInput" placeholder="Type a message..." rows="1"></textarea>
                <button class="send-btn" id="sendBtn" disabled><i class="fas fa-paper-plane"></i></button>
            </div>
        </div>
    </div>

    <!-- Bottom Navigation -->
    <div class="bottom-nav">
        <a href="#" class="nav-btn active"><i class="fas fa-comment-alt"></i>Chats</a>
        <a href="#" class="nav-btn"><i class="fas fa-users"></i>Contacts</a>
        <a href="#" class="nav-btn"><i class="fas fa-cog"></i>Settings</a>
    </div>

    <!-- JavaScript -->
    <script>
        let currentChatId = null;
        let currentChatName = null;
        let currentChatProfile = null;

        // Toggle sidebar and chat on mobile
        function toggleChatView() {
            const sidebar = document.getElementById('sidebar');
            const chatArea = document.getElementById('chatArea');
            sidebar.classList.toggle('hidden');
            chatArea.classList.toggle('active');
        }

        // Load messages for a user
        function loadMessages(userId, username, profilePic) {
            currentChatId = userId;
            currentChatName = username;
            currentChatProfile = profilePic;

            document.getElementById('chatUsername').textContent = username;
            const chatAvatar = document.getElementById('chatUserAvatar');
            if (profilePic) {
                chatAvatar.innerHTML = `<img src="uploads/${profilePic}" class="chat-user-avatar" alt="${username}" />`;
            } else {
                chatAvatar.textContent = username[0].toUpperCase();
            }

            fetch(`?ajax=messages&to=${userId}`)
                .then(res => res.json())
                .then(messages => {
                    const container = document.getElementById('messagesContainer');
                    container.innerHTML = '';
                    if (messages.length === 0) {
                        container.innerHTML = '<div class="empty-state"><div class="empty-icon"><i class="fas fa-comment-alt"></i></div><h3>No messages yet</h3><p>Start a conversation!</p></div>';
                        return;
                    }
                    messages.forEach(msg => {
                        const isMe = msg.sender_id == <?= $user_id ?>;
                        const bubble = document.createElement('div');
                        bubble.className = `message-row ${isMe ? 'me' : 'them'}`;
                        bubble.innerHTML = `
                            <div class="message-bubble">
                                ${msg.message}
                                <div class="message-meta">
                                    <span>${msg.created_at}</span>
                                </div>
                            </div>
                        `;
                        container.appendChild(bubble);
                    });
                    container.scrollTop = container.scrollHeight;
                });

            // Enable send button
            document.getElementById('sendBtn').disabled = false;
        }

        // Send message
        document.getElementById('sendBtn').addEventListener('click', function() {
            const msg = document.getElementById('messageInput').value.trim();
            if (msg && currentChatId) {
                fetch('', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `ajax=send&to=${currentChatId}&msg=${encodeURIComponent(msg)}`
                })
                .then(res => res.json())
                .then(data => {
                    if (data.status === 'success') {
                        document.getElementById('messageInput').value = '';
                        loadMessages(currentChatId, currentChatName, currentChatProfile);
                    }
                });
            }
        });

        // Enter key to send message
        document.getElementById('messageInput').addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                document.getElementById('sendBtn').click();
            }
        });

        // Click user to load chat
        document.querySelectorAll('.user-item').forEach(user => {
            user.addEventListener('click', function() {
                document.querySelectorAll('.user-item').forEach(u => u.classList.remove('active'));
                this.classList.add('active');
                const userId = this.dataset.id;
                const username = this.dataset.username;
                const profilePic = this.dataset.profile;
                loadMessages(userId, username, profilePic);
                if (window.innerWidth <= 768) {
                    toggleChatView();
                }
            });
        });

        // On mobile, show sidebar by default
        if (window.innerWidth <= 768) {
            document.getElementById('chatArea').classList.remove('active');
        }
    </script>
</body>
</html>
