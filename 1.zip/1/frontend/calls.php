<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Calls • Purple WhatsApp UI</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f5f5f5;
    }

    .appbar {
      background-color: #6c47c6;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 1.5rem;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }

    .appbar h1 {
      font-size: 1.5rem;
      margin: 0;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .appbar .bi {
      font-size: 1.5rem;
    }

    .back-btn {
      background: #fff;
      color: #6c47c6;
      border: none;
      padding: 8px 16px;
      border-radius: 8px;
      font-weight: 600;
      text-decoration: none;
      transition: 0.3s;
    }

    .back-btn:hover {
      background: #502ba7;
      color: #fff;
    }

    .calls-container {
      padding: 2rem;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: calc(100vh - 80px);
    }

    .card-style {
      background-color: white;
      border-radius: 16px;
      padding: 3rem 2rem;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
      max-width: 420px;
      width: 100%;
      text-align: center;
    }

    .card-style i {
      font-size: 3rem;
      color: #a084ee;
      margin-bottom: 1rem;
    }

    .card-style .title {
      font-size: 1.4rem;
      font-weight: 600;
      color: #333;
      margin-bottom: 0.5rem;
    }

    .card-style .desc {
      color: #555;
      font-size: 1rem;
    }

    @media (max-width: 576px) {
      .appbar h1 {
        font-size: 1.2rem;
      }
      .card-style {
        padding: 2rem 1rem;
      }
    }
  </style>
</head>
<body>

  <div class="appbar">
    <h1><i class="bi bi-telephone-fill"></i> Calls</h1>
    <a href="dashboard.php" class="back-btn">Dashboard</a>
  </div>

  <div class="calls-container">
    <div class="card-style">
      <i class="bi bi-telephone-x-fill"></i>
      <div class="title">No Calls Yet</div>
      <p class="desc">Your recent calls will show up here once you make or receive them.</p>
    </div>
  </div>

</body>
</html>
