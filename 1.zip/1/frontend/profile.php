<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$user_id = $_SESSION['user_id'];

// Connect to DB
$conn = new mysqli("localhost", "root", "", "1");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user info
$stmt = $conn->prepare("SELECT username, email, profile_photo FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $email, $profile_photo);
$stmt->fetch();
$stmt->close();

$error = '';
$success = '';

// Handle profile photo upload
if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
    $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
    if (!in_array($ext, $allowed)) {
        $error = "Only image files allowed (jpg, jpeg, png, gif, webp, bmp, svg).";
    } else {
        $filename = 'user_' . $user_id . '_' . time() . '.' . $ext;
        $target = 'uploads/' . $filename;
        if (!is_dir('uploads')) mkdir('uploads');
        if (move_uploaded_file($_FILES['photo']['tmp_name'], $target)) {
            // Update DB
            $stmt = $conn->prepare("UPDATE users SET profile_photo=? WHERE id=?");
            $stmt->bind_param("si", $filename, $user_id);
            $stmt->execute();
            $stmt->close();
            $success = "Profile photo updated!";
            $profile_photo = $filename;
        } else {
            $error = "Upload failed.";
        }
    }
}

// Handle username/password change
if (isset($_POST['update_profile'])) {
    $new_username = trim($_POST['username']);
    $new_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $confirm_email = trim($_POST['email']);
    if ($confirm_email !== $email) {
        $error = "Email confirmation failed.";
    } elseif (strlen($new_username) < 3) {
        $error = "Username must be at least 3 characters.";
    } elseif (!empty($new_password) && strlen($new_password) < 6) {
        $error = "Password must be at least 6 characters.";
    } elseif ($new_password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if username is taken (by another user)
        $stmt = $conn->prepare("SELECT id FROM users WHERE username=? AND id!=?");
        $stmt->bind_param("si", $new_username, $user_id);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $error = "Username already taken.";
        } else {
            // Update username and/or password
            if (!empty($new_password)) {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET username=?, password=? WHERE id=?");
                $stmt->bind_param("ssi", $new_username, $hashed, $user_id);
            } else {
                $stmt = $conn->prepare("UPDATE users SET username=? WHERE id=?");
                $stmt->bind_param("si", $new_username, $user_id);
            }
            $stmt->execute();
            $stmt->close();
            $_SESSION['username'] = $new_username;
            $success = "Profile updated!";
            $username = $new_username;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile • Orion</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <style>
        body {
            background: #f4f7fa;
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
            min-height: 100vh;
        }
        .profile-container {
            max-width: 420px;
            width: 96vw;
            margin: 0 auto;
            margin-top: 32px;
            margin-bottom: 32px;
            padding: 32px 4vw 24px 4vw;
            background: #fff;
            border: 1px solid #b8e6ff;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(0,155,255,0.07);
            text-align: center;
        }
        .profile-logo {
            font-family: 'Grand Hotel', cursive;
            font-size: 2.2rem;
            color: #009bff;
            margin-bottom: 18px;
            letter-spacing: 2px;
        }
        .avatar, .avatar-img {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            background: #009bff;
            color: #fff;
            font-size: 2.5rem;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 12px;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 0 6px rgba(0,155,255,0.08);
            cursor: pointer;
            transition: box-shadow 0.2s;
        }
        .avatar:hover, .avatar-img:hover {
            box-shadow: 0 0 0 4px #b8e6ff;
            filter: brightness(0.98);
        }
        .profile-form input[type="text"],
        .profile-form input[type="email"],
        .profile-form input[type="password"] {
            width: 100%;
            padding: 10px 8px;
            margin-bottom: 10px;
            border: 1px solid #b8e6ff;
            background: #f4f7fa;
            border-radius: 4px;
            font-size: 1rem;
        }
        .profile-form button {
            width: 100%;
            padding: 10px 0;
            background: #009bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-weight: bold;
            font-size: 1.1rem;
            cursor: pointer;
            margin-top: 5px;
            transition: background 0.2s;
        }
        .profile-form button:hover {
            background: #0070b8;
        }
        .profile-form label {
            display: block;
            margin-bottom: 5px;
            font-size: 0.97rem;
            color: #009bff;
            text-align: left;
        }
        .error {
            color: #ed4956;
            margin-bottom: 10px;
        }
        .success {
            color: #009bff;
            margin-bottom: 10px;
        }
        .back-link {
            margin-top: 20px;
            font-size: 0.96rem;
        }
        .back-link a {
            color: #009bff;
            text-decoration: none;
            font-weight: bold;
        }
        .logout-link {
            margin-top: 18px;
            font-size: 1.05rem;
        }
        .logout-link a {
            color: #ed4956;
            text-decoration: none;
            font-weight: bold;
        }
        .photo-form {
            margin-bottom: 20px;
        }
        .photo-form input[type="file"] {
            display: none;
        }
        /* Bottom nav bar styles */
        .wa-bottom-nav {
            position: fixed;
            bottom: 0; left: 0; right: 0;
            height: 60px;
            background: #fff;
            border-top: 1px solid #e9edef;
            display: flex;
            justify-content: space-around;
            align-items: center;
            z-index: 1002;
            box-shadow: 0 -2px 8px rgba(44,62,80,0.04);
        }
        .wa-nav-btn {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            color: #7b7b7b;
            font-size: 12px;
            font-family: inherit;
            padding: 7px 0 0 0;
            transition: color 0.2s;
        }
        .wa-nav-btn .wa-nav-icon {
            font-size: 23px;
            margin-bottom: 2px;
        }
        .wa-nav-btn.active,
        .wa-nav-btn:active,
        .wa-nav-btn:focus {
            color: #25d366;
        }
        .wa-nav-btn.active .wa-nav-icon {
            color: #25d366;
        }
        body { padding-bottom: 60px; }
        @media (max-width: 600px) {
            .profile-container { margin-top: 10vw; margin-bottom: 20vw; }
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <div class="profile-logo">Orion</div>
        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($success): ?>
            <div class="success"><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <!-- Profile Photo (avatar is clickable to open gallery/camera) -->
        <form class="photo-form" method="POST" enctype="multipart/form-data">
            <input type="file" name="photo" id="photoInput" accept="image/*" onchange="this.form.submit()">
            <label for="photoInput" style="cursor:pointer; display:inline-block;">
                <?php if ($profile_photo && file_exists('uploads/' . $profile_photo)): ?>
                    <img src="uploads/<?= htmlspecialchars($profile_photo) ?>" alt="Profile Photo" class="avatar-img" id="avatarImg" />
                <?php else: ?>
                    <div class="avatar" id="avatarImg"><?= strtoupper($username[0]) ?></div>
                <?php endif; ?>
            </label>
        </form>

        <!-- Profile Update Form -->
        <form class="profile-form" method="POST" autocomplete="off">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" value="<?= htmlspecialchars($username) ?>" required>

            <label for="password">New Password <small>(leave blank to keep current)</small></label>
            <input type="password" name="password" id="password" placeholder="New Password">

            <label for="confirm_password">Confirm New Password</label>
            <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm New Password">

            <label for="email">Confirm Email</label>
            <input type="email" name="email" id="email" placeholder="Your Email" required value="<?=htmlspecialchars($email)?>">

            <button type="submit" name="update_profile">Update Profile</button>
        </form>
        <div class="back-link">
            <a href="dashboard.php">&larr; Back to Dashboard</a>
        </div>
        <div class="logout-link">
            <a href="login.php" id="logout-link">Logout</a>
        </div>
    </div>
    <!-- WhatsApp iOS-Style Bottom Navigation Bar with Logout -->
    <nav class="wa-bottom-nav">
        <a href="chats.php" class="wa-nav-btn">
            <span class="wa-nav-icon">💬</span>
            <span class="wa-nav-label">Chats</span>
        </a>
        <a href="groups.php" class="wa-nav-btn">
            <span class="wa-nav-icon">👥</span>
            <span class="wa-nav-label">Groups</span>
        </a>
        <a href="communities.php" class="wa-nav-btn">
            <span class="wa-nav-icon">🌐</span>
            <span class="wa-nav-label">Communities</span>
        </a>
        <a href="calls.php" class="wa-nav-btn">
            <span class="wa-nav-icon">📞</span>
            <span class="wa-nav-label">Calls</span>
        </a>
        <a href="profile.php" class="wa-nav-btn active">
            <span class="wa-nav-icon">👤</span>
            <span class="wa-nav-label">Profile</span>
        </a>
    </nav>
    <script>
    // Remove login data from localStorage on logout
    document.addEventListener('DOMContentLoaded', function() {
        function clearLocalAndLogout(e) {
            // Remove any login-related data from localStorage
            localStorage.removeItem('loginData');
            localStorage.removeItem('user_id');
            localStorage.removeItem('username');
            // ...add/remove any other keys you use for login...
            // Let the link continue to logout.php
        }
        var logoutLink = document.getElementById('logout-link');
        if (logoutLink) {
            logoutLink.addEventListener('click', clearLocalAndLogout);
        }
        var logoutNav = document.getElementById('logout-nav');
        if (logoutNav) {
            logoutNav.addEventListener('click', clearLocalAndLogout);
        }
    });
    </script>
</body>
</html>
