// Toggle between login and signup forms
function toggleForm() {
    document.getElementById('loginForm').classList.toggle('active');
    document.getElementById('signupForm').classList.toggle('active');
}

// Splash Screen Logic
window.onload = function() {
    setTimeout(() => {
        document.getElementById('splash').style.opacity = '0';
        setTimeout(() => {
            document.getElementById('splash').style.display = 'none';
            document.getElementById('mainContent').style.display = 'block';
        }, 500);
    }, 2000);
};
document.addEventListener("DOMContentLoaded", function () {
    const loginButton = document.getElementById("loginButton");

    if (loginButton) {
        loginButton.addEventListener("click", function () {
            let username = document.getElementById("username").value;
            let password = document.getElementById("password").value;

            if (username.trim() === "" || password.trim() === "") {
                alert("Please enter both username and password.");
                return;
            }

            // Store user data in localStorage (for now)
            localStorage.setItem("username", username);

            // Redirect to chat selection page
            window.location.href = "chat.html";
        });
    }
});
