document.addEventListener("DOMContentLoaded", function () {
    let username = localStorage.getItem("username") || "User";
    document.getElementById("username").innerText = username;
});

function goToChat(type) {
    switch (type) {
        case 'personal':
            window.location.href = "personal_chat.html";
            break;
        case 'group':
            window.location.href = "group_chat.html";
            break;
        case 'community':
            window.location.href = "community_chat.html";
            break;
        case 'calls':
            window.location.href = "calls.html";
            break;
        default:
            alert("Invalid option!");
    }
}
